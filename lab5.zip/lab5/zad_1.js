function printMushrooms(count) {
  let ending = "";
  if (count % 10 === 1 && count % 100 !== 11) {
    ending = "гриб";
  } else if (count % 10 >= 2 && count % 10 <= 4 && (count % 100 < 10 || count % 100 >= 20)) {
    ending = "гриба";
  } else {
    ending = "грибов";
  }
  console.log(count + " " + ending);
}

// Примеры использования:
printMushrooms(1);   // 1 гриб
printMushrooms(2);   // 2 гриба
printMushrooms(5);   // 5 грибов
printMushrooms(11); // 11 грибов
printMushrooms(12); // 12 грибов
printMushrooms(14); // 14 грибов
printMushrooms(21); // 21 гриб
printMushrooms(101); // 101 гриб

