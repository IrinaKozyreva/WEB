function isPalindrome(word) {
    word = word.toLowerCase().replace(/[^a-zA-Z0-9]/g, ""); // Убираем пробелы и знаки препинания, приводим к нижнему регистру
    const reversedWord = word.split("").reverse().join("");
    return word === reversedWord;
  }
  
  // Примеры:
  console.log(isPalindrome("А роза упала на лапу Азора")); // true
  console.log(isPalindrome("hello")); // false
  console.log(isPalindrome("racecar")); // true
  console.log(isPalindrome("A man, a plan, a canal: Panama")); // true
  console.log(isPalindrome("")); // true (пустая строка - палиндром)